package com.g3dsc.Entity;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import com.g3dsc.Enum.Role;

@Entity
public class User {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int userId;
	private String userName;
	private String firstName;
	private String lastName;
	private String userCity;
	private String userEmail;
	private String userPassword;
	
	@Enumerated(EnumType.STRING)
	private Role role;
	
	@ManyToMany(fetch=FetchType.LAZY,
				cascade=CascadeType.ALL)
	@JoinTable(name="sport_management", joinColumns={@JoinColumn(name="userId")},inverseJoinColumns={@JoinColumn(name="sportId")})
	private Set<Sport> sport;

	@OneToMany(mappedBy = "user")
	private List<Comment> comment;
	
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public User(String userName, String firstName, String lastName, String userCity, String userEmail,
			String userPassword, Role role) {
		super();
		this.userName = userName;
		this.firstName = firstName;
		this.lastName = lastName;
		this.userCity = userCity;
		this.userEmail = userEmail;
		this.userPassword = userPassword;
		this.role = role;
	}
	
	public User(int userId, String userName, String firstName, String lastName, String userCity, String userEmail,
			String userPassword, Role role, Set<Sport> sport) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.firstName = firstName;
		this.lastName = lastName;
		this.userCity = userCity;
		this.userEmail = userEmail;
		this.userPassword = userPassword;
		this.role = role;
		this.sport = sport;
	}

	
	public User(String firstName, String lastName, String userCity, String userEmail) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.userCity = userCity;
		this.userEmail = userEmail;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUserCity() {
		return userCity;
	}

	public void setUserCity(String userCity) {
		this.userCity = userCity;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public Set<Sport> getSport() {
		return sport;
	}

	public void setSport(Set<Sport> sport) {
		this.sport = sport;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", firstName=" + firstName + ", lastName="
				+ lastName + ", userCity=" + userCity + ", userEmail=" + userEmail + ", userPassword=" + userPassword
				+ ", role=" + role + ", sport=" + sport + "]";
	}
	
	
	
	
	

}
