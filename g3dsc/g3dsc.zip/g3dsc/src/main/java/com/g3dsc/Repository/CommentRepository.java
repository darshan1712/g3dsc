package com.g3dsc.Repository;

public interface CommentRepository {

}
