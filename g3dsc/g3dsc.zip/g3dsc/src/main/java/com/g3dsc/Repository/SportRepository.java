package com.g3dsc.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.g3dsc.Entity.Sport;

@Repository
public interface SportRepository extends JpaRepository<Sport, Integer>{

}
