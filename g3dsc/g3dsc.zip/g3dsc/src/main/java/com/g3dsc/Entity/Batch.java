package com.g3dsc.Entity;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Batch {
	@Id
	private int batchId;
	private String batchType;
	private String batchPrice;
	private LocalTime batchStartTime;
	private LocalTime batchEndTime;
	private LocalDate batchStartDate ;
	private LocalDate batchEndDate ;
	//sid fk
}
