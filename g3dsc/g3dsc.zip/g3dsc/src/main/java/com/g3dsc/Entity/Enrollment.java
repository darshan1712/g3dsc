package com.g3dsc.Entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Enrollment {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int enrollmentId;
	private String enrollmentStatus;
	private LocalDate enrollmentDate;
	//private int userId;
	//private int batchId;
}
