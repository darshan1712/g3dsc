package com.g3dsc.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.g3dsc.Entity.User;
import com.g3dsc.Repository.SportRepository;
import com.g3dsc.Repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	SportRepository sportRepository;
	
	public UserServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<User> getUser() {
		System.out.println("in getting user");
		return userRepository.findAll();
	}

	@Override
	public Optional<User> getUserById(int id) {
		return userRepository.findById(id);
	}

	@Override
	public User addUser(User user) {
		return userRepository.save(user);
	}

	@Override
	public void updateUser(int id, User user) {
		
		List<User> userList = userRepository.findAll();
		
		 userList = userList.stream().map(u->{
			if(u.getUserId() == id) {
				u.setUserId(u.getUserId());
				u.setFirstName(user.getFirstName());
				u.setLastName(user.getLastName());
				u.setUserCity(user.getUserCity());
				u.setUserEmail(user.getUserEmail());
				u.setRole(user.getRole());
				u.setUserPassword(user.getUserPassword());
				u.setUserName(user.getUserName());
			}
			userRepository.save(u);
			return u;
		}).collect(Collectors.toList());
		
	
		
		
	}

	@Override
	public void deleteUser(int id) {
		userRepository.deleteById(id);	
	}

	
	

}
