package com.g3dsc.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.g3dsc.Entity.User;
import com.g3dsc.Service.UserService;

@RestController
@RequestMapping("/admin")
public class AdminController {


	@Autowired
	public UserService userService;
	
	
	@GetMapping("/manager")
	private List<User> getManagers(){
		return	userService.getUser();
	}
	
	@GetMapping("/manager/{id}")
	public Optional<User> getManagerById(@PathVariable int id) {
	return userService.getUserById(id);
	}
	
	@PostMapping("/manager")
	private User addManager(@RequestBody User user){
		return userService.addUser(user);
	}
	
	@PutMapping("/manager/{id}")
	private User updateManager(@PathVariable int id, @RequestBody User user) {
		userService.updateUser(id, user);
		return user;
	}
	
	@DeleteMapping("/manager/{id}")
	private String deleteManager(@PathVariable int id) {
		userService.deleteUser(id);
		return "User deleted";
	}
	
}
